import React from 'react';
import { motion } from 'motion/react';

export const WalkingAnimals: React.FC = () => {
  return (
    <div className="fixed inset-0 pointer-events-none z-10 overflow-hidden select-none">
      {/* 1. GÓC DƯỚI BÊN TRÁI: Chú thỏ cầm cà rốt (Lớn hơn, đi lại nhún nhảy) */}
      <motion.div
        animate={{
          x: [10, 75, 10],
          y: [0, -8, 0, -5, 0],
          scaleX: [1, 1, -1, -1, 1],
        }}
        transition={{
          duration: 9,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute bottom-2 left-3 flex flex-col items-center"
      >
        <img
          src="/assets/animals/bunny.png"
          alt="Cute Bunny"
          className="w-16 h-18 sm:w-20 sm:h-22 object-contain filter drop-shadow-md"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </motion.div>

      {/* 2. DƯỚI BÊN TRÁI: Mèo đọc sách chăm chỉ */}
      <motion.div
        animate={{
          rotate: [-3, 3, -3],
          y: [0, -4, 0],
        }}
        transition={{
          duration: 3.5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute bottom-2 left-28 sm:left-36 hidden sm:flex flex-col items-center"
      >
        <img
          src="/assets/animals/cat.png"
          alt="Cute Cat"
          className="w-14 h-16 sm:w-18 sm:h-20 object-contain filter drop-shadow-md"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </motion.div>

      {/* 3. GÓC DƯỚI BÊN PHẢI: Chú cún Shiba ngoe nguẩy (Lớn hơn, dạo chơi) */}
      <motion.div
        animate={{
          x: [-10, -75, -10],
          y: [0, -7, 0, -4, 0],
          scaleX: [-1, -1, 1, 1, -1],
        }}
        transition={{
          duration: 10,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute bottom-2 right-3 flex flex-col items-center"
      >
        <img
          src="/assets/animals/shiba.png"
          alt="Cute Shiba"
          className="w-16 h-18 sm:w-20 sm:h-22 object-contain filter drop-shadow-md"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </motion.div>

      {/* 4. DƯỚI BÊN PHẢI: Vịt trắng lạch bạch */}
      <motion.div
        animate={{
          rotate: [-5, 5, -5],
          x: [0, -30, 0],
          y: [0, -5, 0],
        }}
        transition={{
          duration: 4.5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute bottom-2 right-28 sm:right-36 hidden sm:flex flex-col items-center"
      >
        <img
          src="/assets/animals/duck.png"
          alt="Cute Duck"
          className="w-14 h-16 sm:w-17 sm:h-20 object-contain filter drop-shadow-md"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </motion.div>

      {/* 5. DƯỚI Ở GIỮA: Chim cánh cụt quàng khăn đỏ */}
      <motion.div
        animate={{
          x: [-25, 25, -25],
          y: [0, -4, 0],
          rotate: [-2, 2, -2],
        }}
        transition={{
          duration: 7,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute bottom-2 left-1/2 -translate-x-1/2 hidden md:flex flex-col items-center opacity-90"
      >
        <img
          src="/assets/animals/penguin.png"
          alt="Cute Penguin"
          className="w-13 h-15 sm:w-16 sm:h-18 object-contain filter drop-shadow-md"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </motion.div>

      {/* 6. GÓC TRÊN BÊN TRÁI (ngoài lề nội dung): Gấu trúc đỏ quàng khăn */}
      <motion.div
        animate={{
          y: [0, -6, 0],
          rotate: [-2, 2, -2],
        }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute top-16 left-3 hidden xl:flex flex-col items-center opacity-85"
      >
        <img
          src="/assets/animals/redpanda.png"
          alt="Cute Red Panda"
          className="w-14 h-16 sm:w-16 sm:h-19 object-contain filter drop-shadow-sm"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </motion.div>

      {/* 7. GÓC TRÊN BÊN PHẢI (ngoài lề nội dung): Chuột Hamster đáng yêu */}
      <motion.div
        animate={{
          y: [0, -7, 0],
          rotate: [2, -2, 2],
        }}
        transition={{
          duration: 4.5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute top-16 right-3 hidden xl:flex flex-col items-center opacity-85"
      >
        <img
          src="/assets/animals/hamster.png"
          alt="Cute Hamster"
          className="w-14 h-16 sm:w-16 sm:h-19 object-contain filter drop-shadow-sm"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </motion.div>

      {/* 8. CẠNH GIỮA BÊN TRÁI: Chú hổ con tinh anh */}
      <motion.div
        animate={{
          y: [-5, 5, -5],
          rotate: [-3, 3, -3],
        }}
        transition={{
          duration: 5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute top-1/2 -translate-y-1/2 left-2 hidden 2xl:flex flex-col items-center opacity-80"
      >
        <img
          src="/assets/animals/tiger.png"
          alt="Cute Tiger"
          className="w-14 h-16 sm:w-16 sm:h-19 object-contain filter drop-shadow-sm"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </motion.div>

      {/* 9. CẠNH GIỮA BÊN PHẢI: Chú cừu cầm táo */}
      <motion.div
        animate={{
          y: [5, -5, 5],
          rotate: [3, -3, 3],
        }}
        transition={{
          duration: 5.5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute top-1/2 -translate-y-1/2 right-2 hidden 2xl:flex flex-col items-center opacity-80"
      >
        <img
          src="/assets/animals/sheep.png"
          alt="Cute Sheep"
          className="w-14 h-16 sm:w-16 sm:h-19 object-contain filter drop-shadow-sm"
          referrerPolicy="no-referrer"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
      </motion.div>
    </div>
  );
};
